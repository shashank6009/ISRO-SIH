import torch
import torch.nn as nn
import gpytorch

# ---------------------
# Transformer Forecaster
# ---------------------
class TransformerForecaster(nn.Module):
    """Temporal Transformer model for long-range forecasting."""
    def __init__(self, input_size: int, d_model: int = 128, nhead: int = 4, num_layers: int = 3, output_size: int = 1, dropout: float = 0.1):
        super().__init__()
        self.input_proj = nn.Linear(input_size, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, dim_feedforward=256, dropout=dropout, batch_first=True
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.fc_out = nn.Linear(d_model, output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (batch, seq_len, input_size)
        x = self.input_proj(x)
        encoded = self.encoder(x)
        out = self.fc_out(encoded[:, -1, :])
        return out


# ---------------------
# Gaussian Process Head
# ---------------------
class GPRegressionModel(gpytorch.models.ExactGP):
    """Gaussian Process head for calibrated uncertainty estimation."""
    def __init__(self, train_x, train_y, likelihood):
        super().__init__(train_x, train_y, likelihood)
        self.mean_module = gpytorch.means.ConstantMean()
        self.covar_module = gpytorch.kernels.ScaleKernel(gpytorch.kernels.RBFKernel())

    def forward(self, x):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)


def example_gp_forward():
    """Quick test for GP forward."""
    import numpy as np
    train_x = torch.linspace(0, 1, 10)
    train_y = torch.sin(train_x * (2 * np.pi))
    likelihood = gpytorch.likelihoods.GaussianLikelihood()
    model = GPRegressionModel(train_x, train_y, likelihood)
    model.eval()
    with torch.no_grad():
        pred = model(train_x)
    print("GP mean:", pred.mean[:3])


if __name__ == "__main__":
    # Smoke tests
    t_model = TransformerForecaster(input_size=10)
    x = torch.randn(8, 12, 10)
    print("Transformer output shape:", t_model(x).shape)
    example_gp_forward()
