import torch
import torch.nn as nn
import numpy as np

class BaselineMeanModel:
    """Naive baseline that predicts the mean of training errors."""
    def __init__(self):
        self.mean_ = 0.0

    def fit(self, y: np.ndarray):
        self.mean_ = float(np.mean(y))

    def predict(self, steps: int) -> np.ndarray:
        return np.full(steps, self.mean_)


class GRUForecaster(nn.Module):
    """Multi-horizon GRU forecaster."""
    def __init__(self, input_size: int, hidden_size: int = 128, num_layers: int = 2, output_size: int = 1, dropout: float = 0.1):
        super().__init__()
        self.gru = nn.GRU(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (batch, seq_len, input_size)
        out, _ = self.gru(x)
        out = self.fc(out[:, -1, :])  # last time step
        return out


def example_train_step():
    """Quick sanity test for GRU on random data."""
    model = GRUForecaster(input_size=10)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.MSELoss()

    x = torch.randn(8, 12, 10)
    y = torch.randn(8, 1)
    out = model(x)
    loss = criterion(out, y)
    loss.backward()
    opt.step()
    print("Example train step OK, loss:", loss.item())


if __name__ == "__main__":
    example_train_step()
