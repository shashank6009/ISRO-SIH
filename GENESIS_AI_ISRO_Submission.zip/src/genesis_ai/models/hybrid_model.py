import torch
import torch.nn as nn
import gpytorch
from genesis_ai.models.forecast_models import GRUForecaster
from genesis_ai.models.advanced_models import TransformerForecaster, GPRegressionModel

class HybridForecastModel(nn.Module):
    """
    Hybrid deterministic + probabilistic model.
    1. Combines GRU and Transformer outputs (average fusion).
    2. Feeds fused embedding into Gaussian Process head for uncertainty.
    """
    def __init__(self, input_size: int, hidden_size: int = 128):
        super().__init__()
        self.gru = GRUForecaster(input_size=input_size, hidden_size=hidden_size)
        self.transformer = TransformerForecaster(input_size=input_size, d_model=hidden_size)
        self.fusion = nn.Linear(2, 1)  # fuse GRU + Transformer scalar outputs

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        g_out = self.gru(x)
        t_out = self.transformer(x)
        fused = torch.cat([g_out, t_out], dim=1)
        return self.fusion(fused)


class HybridWithGP:
    """
    Lightweight wrapper: fit GP head on latent predictions to produce uncertainty.
    """
    def __init__(self):
        self.likelihood = None
        self.gp = None

    def fit_gp(self, train_preds: torch.Tensor, train_y: torch.Tensor):
        # Ensure consistent dtypes
        train_preds = train_preds.float()
        train_y = train_y.float()
        self.likelihood = gpytorch.likelihoods.GaussianLikelihood()
        self.gp = GPRegressionModel(train_preds.squeeze(), train_y.squeeze(), self.likelihood)
        self.gp.train()
        self.likelihood.train()
        optimizer = torch.optim.Adam(self.gp.parameters(), lr=0.05)
        mll = gpytorch.mlls.ExactMarginalLogLikelihood(self.likelihood, self.gp)
        for _ in range(50):
            optimizer.zero_grad()
            output = self.gp(train_preds.squeeze())
            loss = -mll(output, train_y.squeeze())
            loss.backward()
            optimizer.step()

    def predict(self, test_preds: torch.Tensor):
        # Ensure consistent dtype
        test_preds = test_preds.float()
        self.gp.eval()
        self.likelihood.eval()
        with torch.no_grad(), gpytorch.settings.fast_pred_var():
            observed_pred = self.likelihood(self.gp(test_preds.squeeze()))
        return observed_pred.mean, observed_pred.variance


if __name__ == "__main__":
    # Smoke test
    model = HybridForecastModel(input_size=10)
    x = torch.randn(5, 12, 10)
    y = model(x)
    print("Hybrid deterministic output:", y.shape)
