# Module: app — handles Streamlit application and dashboard
