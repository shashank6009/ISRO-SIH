import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
from pathlib import Path
import time

from genesis_ai.inference.predictor_client import GenesisClient
from genesis_ai.integration.env_feed import fetch_space_weather, fetch_ionosphere_data, get_ground_stations, fetch_solar_activity, EnvironmentalMonitor

# --- UI Theme ---
st.set_page_config(
    page_title="GENESIS-AI | ISRO Mission Control",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for ISRO look
st.markdown("""
<style>
.stApp {
    background-color: #0b0f23;
    color: #e6edf3;
}
.block-container {
    padding-top: 1rem;
    background-color: #0b0f23;
}
.stSidebar {
    background-color: #161b2e;
}
.stSelectbox > div > div {
    background-color: #1c2333;
    color: #e6edf3;
}
.stSlider > div > div > div > div {
    background-color: #00c9ff;
}
.stButton > button {
    background-color: #00c9ff;
    color: #0b0f23;
    border: none;
    border-radius: 5px;
    font-weight: bold;
}
.stButton > button:hover {
    background-color: #0099cc;
}
.stDataFrame {
    background-color: #1c2333;
}
h1, h2, h3 {
    color: #00c9ff;
}
.stMarkdown {
    color: #e6edf3;
}
</style>
""", unsafe_allow_html=True)

st.title("🛰️ GENESIS-AI Mission Control")
st.caption("Operational GNSS Error Forecasting Platform — Integrated for ISRO")
st.divider()

# Sidebar Controls
with st.sidebar:
    st.header("⚙️ Configuration")
    model_type = st.selectbox("Model Engine", ["gru", "transformer"])
    seq_len = st.slider("Sequence Length", 8, 24, 12)
    hidden_size = st.slider("Hidden Units", 32, 256, 128, 32)
    api_url = st.text_input("Inference API URL", "http://127.0.0.1:8000")
    auto_refresh = st.checkbox("Auto Refresh (every 60s)", False)
    uploaded = st.file_uploader("Upload GNSS Error Data (CSV)", type=["csv"])
    
    st.markdown("---")
    st.markdown("### 🔧 System Status")
    
    # API Health Check
    try:
        client = GenesisClient(base_url=api_url)
        health = client.health_check()
        st.success("✅ API Service Online")
        st.json(health)
    except Exception as e:
        st.error(f"❌ API Service Offline: {str(e)[:50]}...")

# Space Weather & Environmental Conditions Panel
st.subheader("🌦️ Space Weather & Environmental Conditions")
with st.container():
    try:
        # Get comprehensive environmental status
        env_monitor = EnvironmentalMonitor()
        env_status = env_monitor.get_comprehensive_status()
        
        # Display key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        # Space Weather
        sw_data = env_status["space_weather"]
        if "error" not in sw_data:
            kp_val = sw_data.get("kp_index", 0)
            severity = sw_data.get("severity", "unknown")
            col1.metric(
                "Kp Index", 
                f"{kp_val:.1f}",
                delta=severity.title(),
                help="Geomagnetic disturbance level (0–9). Higher values indicate more ionospheric disturbance."
            )
        else:
            col1.error("Space Weather Offline")
        
        # Ionosphere
        ion_data = env_status["ionosphere"]
        if "error" not in ion_data:
            tec_val = ion_data.get("TEC_avg", 0)
            quality = ion_data.get("quality", "unknown")
            col2.metric(
                "Avg TEC", 
                f"{tec_val:.1f} TECU",
                delta=quality.title(),
                help="Total Electron Content in TEC Units. Affects GNSS signal delay."
            )
        else:
            col2.error("Ionosphere Data Offline")
        
        # Solar Activity
        solar_data = env_status["solar_activity"]
        if "error" not in solar_data:
            f107_val = solar_data.get("f107_flux", 0)
            activity = solar_data.get("activity_level", "unknown")
            col3.metric(
                "F10.7 Flux",
                f"{f107_val:.1f} SFU",
                delta=activity.replace("_", " ").title(),
                help="Solar radio flux at 10.7 cm. Indicates solar activity level."
            )
        else:
            col3.error("Solar Data Offline")
        
        # Overall Health
        health = env_status["overall_health"]
        health_color = {
            "excellent": "🟢",
            "good": "🟡", 
            "fair": "🟠",
            "poor": "🔴"
        }.get(health["status"], "⚪")
        
        col4.metric(
            "GNSS Environment",
            f"{health_color} {health['score']:.0f}/100",
            delta=health["status"].title(),
            help="Overall GNSS operating environment health score"
        )
        
        # Environmental recommendations
        if env_status["recommendations"]:
            with st.expander("📋 Operational Recommendations"):
                for rec in env_status["recommendations"]:
                    st.write(f"• {rec}")
        
        # Last update time
        st.caption(f"Environmental data updated: {datetime.now().strftime('%H:%M:%S UTC')}")
        
    except Exception as e:
        st.error(f"Environmental monitoring error: {str(e)[:100]}...")

st.divider()

if uploaded:
    df = pd.read_csv(uploaded, parse_dates=["timestamp"])
    
    # Data Summary
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Records", len(df))
    with col2:
        st.metric("Satellites", df['sat_id'].nunique())
    with col3:
        st.metric("Orbit Classes", df['orbit_class'].nunique())
    with col4:
        st.metric("Time Span", f"{(df['timestamp'].max() - df['timestamp'].min()).days}d")
    
    st.success(f"📡 Loaded telemetry from {df['sat_id'].nunique()} satellites across {df['orbit_class'].nunique()} orbit classes")

    if st.button("🚀 Run ISRO Forecast", type="primary"):
        with st.spinner("Computing multi-horizon forecasts via /predict_pro..."):
            try:
                client = GenesisClient(base_url=api_url)
                result = client.predict_pro(df, model_type=model_type, seq_len=seq_len, hidden_size=hidden_size)
                preds = pd.DataFrame(result["predictions"])
                preds["timestamp"] = pd.to_datetime(preds["timestamp"])
                
                st.success("🎯 Forecast computation complete!")
                
                # Store in session state for auto-refresh
                st.session_state.predictions = preds
                st.session_state.forecast_info = result["info"]
                st.session_state.last_update = datetime.now()
                
            except Exception as e:
                st.error(f"❌ Forecast failed: {str(e)}")
                st.stop()

    # Display results if available
    if "predictions" in st.session_state:
        preds = st.session_state.predictions
        info = st.session_state.forecast_info
        
        st.subheader("📊 Multi-Horizon Forecast Results")
        
        # Forecast Info Panel
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Model Type", info.get("model_type", "N/A").upper())
        with col2:
            st.metric("Sequence Length", info.get("seq_len", "N/A"))
        with col3:
            st.metric("Hidden Size", info.get("hidden_size", "N/A"))
        with col4:
            st.metric("Confidence", info.get("gp_confidence", "N/A"))
        
        # Results Table
        st.dataframe(
            preds.style.background_gradient(subset=["predicted_error"], cmap="RdYlBu_r")
                      .format({"predicted_error": "{:.4f}", "lower_bound": "{:.4f}", "upper_bound": "{:.4f}"}),
            use_container_width=True
        )

        # Plotting section
        st.subheader("🔮 Predicted Error Timeline")
        
        # Create interactive plot with confidence bands
        fig = go.Figure()
        
        # Group by satellite for different colors
        satellites = preds['sat_id'].unique()
        colors = px.colors.qualitative.Set1
        
        for i, sat in enumerate(satellites):
            sat_data = preds[preds['sat_id'] == sat].sort_values('timestamp')
            color = colors[i % len(colors)]
            
            # Main prediction line
            fig.add_trace(go.Scatter(
                x=sat_data["timestamp"],
                y=sat_data["predicted_error"],
                mode="lines+markers",
                name=f"{sat} - Predicted",
                line=dict(color=color, width=3),
                marker=dict(size=8)
            ))
            
            # Confidence band
            if "lower_bound" in sat_data.columns and "upper_bound" in sat_data.columns:
                fig.add_trace(go.Scatter(
                    x=pd.concat([sat_data["timestamp"], sat_data["timestamp"][::-1]]),
                    y=pd.concat([sat_data["upper_bound"], sat_data["lower_bound"][::-1]]),
                    fill="toself",
                    fillcolor=f"rgba({int(color[4:6], 16)}, {int(color[6:8], 16)}, {int(color[8:10], 16)}, 0.2)",
                    line=dict(color="rgba(255,255,255,0)"),
                    showlegend=False,
                    name=f"{sat} - Confidence",
                    hovertemplate="Confidence Band<extra></extra>"
                ))
        
        fig.update_layout(
            template="plotly_dark",
            paper_bgcolor="#0b0f23",
            plot_bgcolor="#161b2e",
            font=dict(color="#e6edf3", size=12),
            xaxis_title="Time (UTC)",
            yaxis_title="Predicted Error (ns or m)",
            height=600,
            hovermode="x unified",
            legend=dict(
                bgcolor="rgba(22, 27, 46, 0.8)",
                bordercolor="#00c9ff",
                borderwidth=1
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)

        # ISRO Ground Station Network Map
        st.subheader("🗺️ ISRO Ground Station Network")
        
        try:
            stations_df = get_ground_stations()
            
            # Create ground station map using Plotly
            fig_geo = go.Figure()
            
            # Add ground stations
            online_stations = stations_df[stations_df['status'] == 'online']
            offline_stations = stations_df[stations_df['status'] != 'online']
            
            if len(online_stations) > 0:
                fig_geo.add_trace(go.Scattergeo(
                    lon=online_stations['lon'],
                    lat=online_stations['lat'],
                    text=online_stations['station'] + '<br>TEC: ' + online_stations['TEC'].astype(str) + ' TECU',
                    mode='markers+text',
                    marker=dict(size=12, color='#00c9ff', symbol='circle'),
                    textposition="top center",
                    name='Online Stations',
                    hovertemplate='<b>%{text}</b><br>Status: Online<extra></extra>'
                ))
            
            if len(offline_stations) > 0:
                fig_geo.add_trace(go.Scattergeo(
                    lon=offline_stations['lon'],
                    lat=offline_stations['lat'],
                    text=offline_stations['station'],
                    mode='markers+text',
                    marker=dict(size=10, color='#ff6b6b', symbol='x'),
                    textposition="top center",
                    name='Offline Stations',
                    hovertemplate='<b>%{text}</b><br>Status: Maintenance<extra></extra>'
                ))
            
            fig_geo.update_layout(
                geo=dict(
                    projection_type='natural earth',
                    showland=True,
                    landcolor='#1e2130',
                    showocean=True,
                    oceancolor='#0b0f23',
                    showlakes=True,
                    lakecolor='#0b0f23',
                    showrivers=True,
                    rivercolor='#0b0f23',
                    showcountries=True,
                    countrycolor='#404040',
                    center=dict(lat=20, lon=78),  # Center on India
                    projection_scale=3
                ),
                title=dict(
                    text="ISRO Ionospheric Monitoring Network",
                    font=dict(color='#e6edf3', size=16)
                ),
                paper_bgcolor='#0b0f23',
                plot_bgcolor='#0b0f23',
                font=dict(color='#e6edf3'),
                height=400,
                showlegend=True,
                legend=dict(
                    bgcolor="rgba(22, 27, 46, 0.8)",
                    bordercolor="#00c9ff",
                    borderwidth=1
                )
            )
            
            st.plotly_chart(fig_geo, use_container_width=True)
            
            # Station status summary
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Online Stations", len(online_stations))
            with col2:
                st.metric("Maintenance", len(offline_stations))
            with col3:
                avg_tec = stations_df['TEC'].mean()
                st.metric("Network Avg TEC", f"{avg_tec:.1f} TECU")
                
        except Exception as e:
            st.error(f"Ground station map error: {str(e)[:50]}...")

        # Satellite Summary Dashboard
        st.subheader("📡 Satellite Performance Dashboard")
        
        sat_summary = preds.groupby(["sat_id", "orbit_class"]).agg({
            "predicted_error": ["mean", "std", "min", "max"],
            "lower_bound": "min",
            "upper_bound": "max"
        }).round(4)
        
        sat_summary.columns = ["Mean Error", "Std Error", "Min Error", "Max Error", "Min Bound", "Max Bound"]
        sat_summary = sat_summary.reset_index()
        
        # Color-code by orbit class
        orbit_colors = {"GEO/GSO": "#ff6b6b", "MEO": "#4ecdc4", "LEO": "#45b7d1"}
        
        for orbit in sat_summary["orbit_class"].unique():
            orbit_data = sat_summary[sat_summary["orbit_class"] == orbit]
            st.markdown(f"#### {orbit} Satellites")
            
            cols = st.columns(len(orbit_data))
            for i, (_, row) in enumerate(orbit_data.iterrows()):
                with cols[i % len(cols)]:
                    st.metric(
                        label=f"🛰️ {row['sat_id']}",
                        value=f"{row['Mean Error']:.4f}",
                        delta=f"±{row['Std Error']:.4f}"
                    )
        
        # Last update info
        if "last_update" in st.session_state:
            st.caption(f"Last updated: {st.session_state.last_update.strftime('%Y-%m-%d %H:%M:%S UTC')}")

else:
    st.info("📂 Upload GNSS CSV data to begin operational forecasting.")
    
    # Show sample data format
    with st.expander("📋 Expected Data Format"):
        st.markdown("""
        Your CSV should contain these columns:
        - `sat_id`: Satellite identifier (e.g., "SAT-001")
        - `orbit_class`: "GEO/GSO", "MEO", or "LEO"
        - `quantity`: "clock" or "ephem"
        - `timestamp`: ISO format datetime (e.g., "2025-01-01T00:00:00Z")
        - `error`: Numerical error value (ns for clock, m for ephemeris)
        """)

# Operations Console
st.markdown("## 🧭 Operations Console")
tab1, tab2, tab3 = st.tabs(["Database Records", "Alerts & Monitoring", "System Health"])

with tab1:
    st.markdown("### 📊 Database Statistics")
    
    try:
        from genesis_ai.db.models import ForecastRecord, TrainingRun, AlertRecord, get_engine, get_session, get_db_stats, init_database
        
        # Initialize database if needed
        engine = init_database()
        stats = get_db_stats(engine)
        
        # Display metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Forecast Records", stats.get('forecast_records', 0))
        with col2:
            st.metric("Training Runs", stats.get('training_runs', 0))
        with col3:
            st.metric("Alert Records", stats.get('alert_records', 0))
        
        # Show recent records
        if st.button("📋 Show Recent Forecasts"):
            session = get_session(engine)
            try:
                records = session.query(ForecastRecord).order_by(ForecastRecord.created_at.desc()).limit(20).all()
                if records:
                    df_records = pd.DataFrame([{
                        'ID': r.id,
                        'Satellite': r.sat_id,
                        'Orbit': r.orbit_class,
                        'Quantity': r.quantity,
                        'Predicted Error': f"{r.predicted_error:.4f}",
                        'Confidence': f"[{r.lower_bound:.3f}, {r.upper_bound:.3f}]" if r.lower_bound else "N/A",
                        'Model': r.model_type,
                        'Created': r.created_at.strftime('%Y-%m-%d %H:%M')
                    } for r in records])
                    st.dataframe(df_records, use_container_width=True)
                else:
                    st.info("No forecast records found")
            finally:
                session.close()
        
        # Show recent training runs
        if st.button("🏃 Show Recent Training"):
            session = get_session(engine)
            try:
                runs = session.query(TrainingRun).order_by(TrainingRun.started_at.desc()).limit(10).all()
                if runs:
                    df_runs = pd.DataFrame([{
                        'ID': r.id,
                        'Model': r.model_type,
                        'Status': r.status,
                        'Epochs': r.epochs,
                        'Duration': f"{r.training_duration:.1f}s" if r.training_duration else "N/A",
                        'Final Loss': f"{r.final_loss:.4f}" if r.final_loss else "N/A",
                        'Started': r.started_at.strftime('%Y-%m-%d %H:%M')
                    } for r in runs])
                    st.dataframe(df_runs, use_container_width=True)
                else:
                    st.info("No training runs found")
            finally:
                session.close()
                
    except Exception as e:
        st.error(f"Database error: {e}")

with tab2:
    st.markdown("### 🚨 Alert System")
    
    try:
        from genesis_ai.monitor.alerts import AlertManager, MonitoringService
        
        alert_manager = AlertManager()
        
        # Alert statistics
        recent_alerts = alert_manager.get_recent_alerts(hours=24)
        critical_alerts = [a for a in recent_alerts if a.severity == 'critical']
        high_alerts = [a for a in recent_alerts if a.severity == 'high']
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("24h Alerts", len(recent_alerts))
        with col2:
            st.metric("Critical", len(critical_alerts), delta=None if len(critical_alerts) == 0 else f"+{len(critical_alerts)}")
        with col3:
            st.metric("High Priority", len(high_alerts))
        with col4:
            unack_alerts = [a for a in recent_alerts if not a.acknowledged]
            st.metric("Unacknowledged", len(unack_alerts))
        
        # Recent alerts table
        if recent_alerts:
            st.markdown("#### Recent Alerts")
            df_alerts = pd.DataFrame([{
                'ID': a.id,
                'Type': a.alert_type,
                'Severity': a.severity,
                'Satellite': a.sat_id or 'System',
                'Message': a.message[:50] + '...' if len(a.message) > 50 else a.message,
                'Status': '✅ Ack' if a.acknowledged else '⏳ Pending',
                'Time': a.created_at.strftime('%H:%M')
            } for a in recent_alerts[:10]])
            
            # Color code by severity
            def color_severity(val):
                colors = {
                    'critical': 'background-color: #ffebee',
                    'high': 'background-color: #fff3e0', 
                    'medium': 'background-color: #f3e5f5',
                    'low': 'background-color: #e8f5e8'
                }
                return colors.get(val, '')
            
            styled_df = df_alerts.style.applymap(color_severity, subset=['Severity'])
            st.dataframe(styled_df, use_container_width=True)
        else:
            st.success("🎉 No recent alerts - all systems nominal")
        
        # Test alert system
        if st.button("🧪 Test Alert System"):
            alert_id = alert_manager.create_alert(
                alert_type='test',
                severity='low',
                message='Test alert from mission control dashboard',
                details={'source': 'streamlit_ui', 'timestamp': datetime.now().isoformat()}
            )
            st.success(f"Test alert created (ID: {alert_id})")
            
    except Exception as e:
        st.error(f"Alert system error: {e}")

with tab3:
    st.markdown("### 🔧 System Health")
    
    # System status indicators
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Service Status")
        
        # API Health
        try:
            client = GenesisClient(base_url=api_url)
            health = client.health_check()
            st.success("✅ Inference API Online")
        except:
            st.error("❌ Inference API Offline")
        
        # Database Health
        try:
            from sqlalchemy import text
            engine = get_engine()
            session = get_session(engine)
            session.execute(text("SELECT 1"))
            session.close()
            st.success("✅ Database Connected")
        except:
            st.error("❌ Database Offline")
        
        # Data Directory
        data_dir = Path("data")
        if data_dir.exists():
            csv_files = list(data_dir.glob("*.csv"))
            st.success(f"✅ Data Directory ({len(csv_files)} files)")
        else:
            st.warning("⚠️ Data Directory Not Found")
    
    with col2:
        st.markdown("#### Performance Metrics")
        
        # Last update time
        if "last_update" in st.session_state:
            last_update = st.session_state.last_update
            time_since = datetime.now() - last_update
            st.metric("Last Forecast", f"{time_since.seconds//60}m ago")
        
        # System uptime (placeholder)
        st.metric("System Uptime", "24h 15m")
        
        # Memory usage (placeholder)
        st.metric("Memory Usage", "2.1 GB")
        
        # Active connections (placeholder)
        st.metric("Active Sessions", "3")
    
    # System logs (placeholder)
    st.markdown("#### Recent System Events")
    with st.expander("View System Logs"):
        st.code("""
[2025-01-07 17:45:12] INFO - Forecast computation completed for IRNSS-1A
[2025-01-07 17:44:58] INFO - API health check passed
[2025-01-07 17:44:45] INFO - Database connection established
[2025-01-07 17:44:30] INFO - Streamlit dashboard started
[2025-01-07 17:44:15] INFO - GENESIS-AI system initialized
        """)

# Auto-refresh functionality
if auto_refresh and "predictions" in st.session_state:
    time.sleep(1)  # Small delay to prevent excessive refreshing
    st.rerun()

st.markdown("---")
st.caption("© 2025 GENESIS-AI | ISRO GNSS Research Division — Real-time Predictive Analytics")
