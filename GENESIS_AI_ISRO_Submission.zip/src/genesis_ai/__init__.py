"""
GENESIS-AI: Generative GNSS Error Forecasting System
"""

__version__ = "0.1.0"
