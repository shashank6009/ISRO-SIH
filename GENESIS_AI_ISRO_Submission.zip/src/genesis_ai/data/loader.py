import pandas as pd
import numpy as np
from pathlib import Path
from typing import Literal, Union

REQUIRED_COLUMNS = ["sat_id", "orbit_class", "quantity", "timestamp", "error"]

def load_and_validate(csv_path: Union[str, Path]) -> pd.DataFrame:
    """Load GNSS error dataset and validate schema."""
    df = pd.read_csv(csv_path)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df

def resample_and_impute(
    df: pd.DataFrame,
    interval: str = "15min",
    method: Literal["linear", "ffill", "bfill"] = "linear",
) -> pd.DataFrame:
    """Resample to a fixed 15-minute grid and impute missing errors."""
    resampled = []
    for (sat, orbit, qty), group in df.groupby(["sat_id", "orbit_class", "quantity"]):
        g = group.set_index("timestamp").sort_index()
        # Only resample the numeric error column
        g_resampled = g[["error"]].resample(interval).mean()
        mask = g_resampled["error"].isna()
        if method == "linear":
            g_resampled["error"] = g_resampled["error"].interpolate(limit_direction="both")
        elif method == "ffill":
            g_resampled["error"] = g_resampled["error"].ffill()
        elif method == "bfill":
            g_resampled["error"] = g_resampled["error"].bfill()
        g_resampled["is_imputed"] = mask.astype(int)
        g_resampled["sat_id"], g_resampled["orbit_class"], g_resampled["quantity"] = sat, orbit, qty
        resampled.append(g_resampled.reset_index())
    return pd.concat(resampled, ignore_index=True)

if __name__ == "__main__":
    sample_path = "data/sample.csv"
    print("Loading sample:", sample_path)
    df = load_and_validate(sample_path)
    print("Rows loaded:", len(df))
    out = resample_and_impute(df)
    print(out.head())
