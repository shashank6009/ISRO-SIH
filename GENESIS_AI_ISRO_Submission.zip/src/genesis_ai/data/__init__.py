# Module: data — handles loading, validation, and preprocessing
